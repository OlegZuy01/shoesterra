<h2><?php _e('WP All Export Support', 'PMXE_plugin') ?></h2>

<table class="layout">
	<tr>
		<td class="left">
			<p style='font-size: 1.3em;'>
				<b>E-mail</b> - <a href='mailto:support@soflyy.com'>support@soflyy.com</a><br />
				<b>Support page</b> - <a href='http://www.wpallimport.com/support?utm_source=wordpress.org&utm_medium=support&utm_campaign=free+plugin' target='_blank'>http://www.wpallimport.com/support</a>
			</p>			
		</td>
		<td class="right">&nbsp;</td>
	</tr>
</table>